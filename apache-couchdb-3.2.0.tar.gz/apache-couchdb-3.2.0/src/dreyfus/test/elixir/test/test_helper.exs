Code.require_file "../../../../couchdb/test/elixir/lib/couch.ex", __DIR__
Code.require_file "../../../../couchdb/test/elixir/test/test_helper.exs", __DIR__
Code.require_file "../../../../couchdb/test/elixir/test/support/couch_test_case.ex", __DIR__
Code.require_file "../../../../couchdb/test/elixir/lib/couch/db_test.ex", __DIR__
