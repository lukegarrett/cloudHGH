# Used by "mix format"
[
  inputs: [
    "{mix,.formatter}.exs",
    "{config,src}/*/test/exunit/*.{ex,exs}"
  ],
  line_length: 90,
  rename_deprecated_at: "1.5.0"
]
