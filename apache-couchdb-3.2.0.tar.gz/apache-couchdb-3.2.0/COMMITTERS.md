Apache CouchDB COMMITTERS
=========================

Committers are given a binding vote in certain project decisions, as well as
write access to public project infrastructure. Committers are elected to the
project in recognition of their committment to Apache CouchDB. We mean this in
the sense of being loyal to the project and its interests.

A full list of committers elected to the project is available at:

    https://people.apache.org/committers-by-project.html#couchdb
